package com.codegym.dao;

import com.codegym.model.User;
import java.sql.SQLException;
import java.util.List;

/** Defines the persistence operations available for users. */
public interface IUserDAO {
    void insertUser(User user) throws SQLException;
    User selectUser(int id) throws SQLException;
    List<User> selectAllUsers() throws SQLException;
    boolean deleteUser(int id) throws SQLException;
    boolean updateUser(User user) throws SQLException;

    /** Calls the MySQL get_user_by_id stored procedure. */
    User getUserById(int id) throws SQLException;

    /** Calls the MySQL insert_user stored procedure. */
    void insertUserStore(User user) throws SQLException;
}
