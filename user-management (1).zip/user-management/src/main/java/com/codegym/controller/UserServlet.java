package com.codegym.controller;

import com.codegym.dao.UserDAO;
import com.codegym.model.User;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;

/** Routes user requests to the DAO and JSP views. */
public class UserServlet extends HttpServlet {
    private UserDAO userDAO;

    @Override
    public void init() {
        userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        if (action == null || action.isBlank()) action = "list";

        try {
            switch (action) {
                case "create" -> forward(request, response, "/user/create.jsp");
                case "edit" -> showEditForm(request, response);
                case "delete" -> showDeleteForm(request, response);
                case "list" -> listUsers(request, response);
                default -> response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (SQLException e) {
            throw new ServletException("Could not load user data", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");

        try {
            if ("create".equals(action)) {
                User user = readUserForm(request);
                userDAO.insertUserStore(user);
            } else if ("edit".equals(action)) {
                User user = readUserForm(request);
                user.setId(parseId(request));
                userDAO.updateUser(user);
            } else if ("delete".equals(action)) {
                userDAO.deleteUser(parseId(request));
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Unknown user action");
                return;
            }
            response.sendRedirect(request.getContextPath() + "/users");
        } catch (SQLException e) {
            throw new ServletException("Could not save user data", e);
        }
    }

    private void listUsers(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        request.setAttribute("listUser", userDAO.selectAllUsers());
        forward(request, response, "/user/list.jsp");
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        User user = userDAO.getUserById(parseId(request));
        if (user == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "User not found");
            return;
        }
        request.setAttribute("user", user);
        forward(request, response, "/user/edit.jsp");
    }

    private void showDeleteForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        User user = userDAO.selectUser(parseId(request));
        if (user == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "User not found");
            return;
        }
        request.setAttribute("user", user);
        forward(request, response, "/user/delete.jsp");
    }

    private User readUserForm(HttpServletRequest request) {
        return new User(
                request.getParameter("name"),
                request.getParameter("email"),
                request.getParameter("country"));
    }

    private int parseId(HttpServletRequest request) throws ServletException {
        try {
            return Integer.parseInt(request.getParameter("id"));
        } catch (NumberFormatException | NullPointerException e) {
            throw new ServletException("A valid user id is required", e);
        }
    }

    private void forward(HttpServletRequest request, HttpServletResponse response, String path)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher(path);
        dispatcher.forward(request, response);
    }
}
