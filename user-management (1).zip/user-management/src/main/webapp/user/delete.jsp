<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Xóa User</title>
<style>body{font-family:Arial,sans-serif;background:#f4f7fb;margin:32px;color:#1f2937}.card{max-width:520px;margin:auto;background:white;padding:28px;border-radius:12px;box-shadow:0 8px 28px #17255412}h1{color:#b42318}button,.link{display:inline-block;margin:14px 8px 0 0;padding:10px 14px;border:0;border-radius:6px;background:#c0392b;color:white;text-decoration:none;cursor:pointer}.link{background:#64748b}</style>
</head>
<body><main class="card"><h1>Xác nhận xóa User</h1>
<p>Bạn có chắc muốn xóa <strong><c:out value="${user.name}"/></strong> không?</p>
<p>Email: <c:out value="${user.email}"/> · Quốc gia: <c:out value="${user.country}"/></p>
<form action="${pageContext.request.contextPath}/users?action=delete" method="post">
<input type="hidden" name="id" value="<c:out value='${user.id}'/>">
<button type="submit">Xóa User</button><a class="link" href="${pageContext.request.contextPath}/users">Hủy</a>
</form></main></body>
</html>
