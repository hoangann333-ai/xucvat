<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Quản lý User</title>
    <style>
        body{font-family:Arial,sans-serif;margin:32px;background:#f4f7fb;color:#1f2937}
        main{max-width:1000px;margin:auto;background:white;padding:28px;border-radius:12px;box-shadow:0 8px 28px #17255412}
        h1{color:#1d3b8b}.top{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}
        a.button,button{background:#2457d6;color:white;padding:9px 13px;border:0;border-radius:6px;text-decoration:none;cursor:pointer}
        table{width:100%;border-collapse:collapse}th,td{padding:12px;border-bottom:1px solid #e5e7eb;text-align:left}th{background:#eef3ff}
        .actions{display:flex;gap:8px;align-items:center}.danger{background:#c0392b!important}
    </style>
</head>
<body>
<main>
    <div class="top"><h1>Danh sách User</h1><a class="button" href="${pageContext.request.contextPath}/users?action=create">Thêm User</a></div>
    <table>
        <thead><tr><th>ID</th><th>Tên</th><th>Email</th><th>Quốc gia</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="user" items="${listUser}">
            <tr>
                <td><c:out value="${user.id}"/></td>
                <td><c:out value="${user.name}"/></td>
                <td><c:out value="${user.email}"/></td>
                <td><c:out value="${user.country}"/></td>
                <td class="actions">
                    <a class="button" href="${pageContext.request.contextPath}/users?action=edit&amp;id=${user.id}">Sửa</a>
                    <a class="button danger" href="${pageContext.request.contextPath}/users?action=delete&amp;id=${user.id}">Xóa</a>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty listUser}"><tr><td colspan="5">Chưa có user nào.</td></tr></c:if>
        </tbody>
    </table>
</main>
</body>
</html>
