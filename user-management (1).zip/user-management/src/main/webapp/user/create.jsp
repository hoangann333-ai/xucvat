<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Thêm User</title>
<style>body{font-family:Arial,sans-serif;background:#f4f7fb;margin:32px;color:#1f2937}.card{max-width:520px;margin:auto;background:white;padding:28px;border-radius:12px;box-shadow:0 8px 28px #17255412}h1{color:#1d3b8b}label{display:block;margin:14px 0 6px}input{box-sizing:border-box;width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:6px}button,.link{display:inline-block;margin-top:18px;padding:10px 14px;border:0;border-radius:6px;background:#2457d6;color:white;text-decoration:none;cursor:pointer}</style>
</head>
<body><main class="card"><h1>Thêm User</h1>
<form action="${pageContext.request.contextPath}/users?action=create" method="post">
<label for="name">Tên</label><input id="name" name="name" maxlength="120" required>
<label for="email">Email</label><input id="email" name="email" type="email" maxlength="220" required>
<label for="country">Quốc gia</label><input id="country" name="country" maxlength="120">
<button type="submit">Lưu</button><a class="link" href="${pageContext.request.contextPath}/users">Quay lại</a>
</form></main></body>
</html>
