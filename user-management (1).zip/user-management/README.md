# User Management — JSP / Servlet / JDBC / MySQL

Maven WAR app for Java 17, Jakarta Servlet 6, JSP 3.1, JSTL 3 and Tomcat 10.1+.

## 1. Prepare MySQL

Run `database.sql` in MySQL Workbench or another MySQL client. It creates `demo.users` and the `get_user_by_id` / `insert_user` procedures.

## 2. Configure the database login

The application defaults to `root` / `password` on `localhost:3306`. Set these environment variables before starting Tomcat if your local MySQL credentials differ:

- `DB_URL` (optional; default points to `jdbc:mysql://localhost:3306/demo`)
- `DB_USER`
- `DB_PASSWORD`

Windows PowerShell example: `$env:DB_USER='root'; $env:DB_PASSWORD='your-password'`.

## 3. Build and deploy

From this directory run `mvn clean package`; the output is `target/user-management.war`. Deploy it to Tomcat 10.1+ and open `http://localhost:8080/user-management/users`.

The add and edit-form lookup operations call MySQL stored procedures through JDBC `CallableStatement`. Listing, update, and delete use parameterized `PreparedStatement` queries. Delete is submitted with POST.
